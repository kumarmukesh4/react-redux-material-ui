const API_BASE_PATH = () => {
    let url = 'http://34.231.158.137:3001' //'http://localhost:3000';
    return url;
}    

export {
    API_BASE_PATH
}