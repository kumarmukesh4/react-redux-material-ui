import AppointmentReducer from './appointmentReducer'
import authReducer from './authReducer'

export {
    AppointmentReducer,
    authReducer
};