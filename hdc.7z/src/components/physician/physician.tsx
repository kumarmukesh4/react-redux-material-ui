import React from 'react'


function Physician() {
    return (
        <div>
            
        </div>
    )
}


export default Physician